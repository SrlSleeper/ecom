package com.appdev.set;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SetApplicationTests {

	@Test
	void contextLoads() {
	}

}
